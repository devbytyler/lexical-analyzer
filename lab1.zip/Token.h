#include <string>

using namespace std;

enum TokenType{
  COMMA, PERIOD, Q_MARK, LEFT_PAREN, RIGHT_PAREN, COLON, COLON_DASH, MULTIPLY, ADD, SCHEMES, FACTS, RULES, QUERIES, ID, STRING, COMMENT, UNDEFINED, ENDFILE
};

class Token
{
  public:
    Token(string value, TokenType token_type, int line_number);
    ~Token();
    string toString();

  private:
    string value;
    TokenType token_type;
    int line_number;
    string enumToString(TokenType tt);
};
