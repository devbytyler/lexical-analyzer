#include "InputStream.h"



InputStream::InputStream(string file_name)
{
  buildString(file_name);
  currentLoc = 0;
  currentLine = 1;
  atEnd = false;
}

InputStream::~InputStream()
{

}

char InputStream::now()
{
  return str[currentLoc];
}

void InputStream::buildString(string file_name)
{
  ifstream infile;
  stringstream ss;
  string line;

  infile.open(file_name);
  while (getline(infile, line)) {
    ss << line << endl ;
  }
  str = ss.str();
  infile.close();
}

void InputStream::print()
{
  cout << str;
}

int InputStream::getCurrentLoc()
{
 return currentLoc;
}

int InputStream::getCurrentLine()
{
 return currentLine;
}

bool InputStream::isAtEnd(){
  return atEnd;
}

void InputStream::advanceBy(int i)
{
  for (int j = 0; j < i; j++) {
    if (currentLoc + 1 >= str.length()){
      atEnd = true;
      return;
    }
    else {
      if (str[currentLoc] == '\n') {
        currentLine++;
        // currentLoc++;
      }
      currentLoc++;
    }
  }
}

char InputStream::lookAhead(int i)
{
  if (currentLoc + i < str.length()) {
    return str[currentLoc + i];
  }
  else {
    return '\0';
  }
}