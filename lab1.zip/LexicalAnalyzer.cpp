#include "LexicalAnalyzer.h"

LexicalAnalyzer::LexicalAnalyzer(string file_name) : input(file_name){}

LexicalAnalyzer::~LexicalAnalyzer(){}

void LexicalAnalyzer::tokenize()
{
  while (!input.isAtEnd()){
    if (isspace(input.now())) {
      input.advanceBy(1);
    }
    readSingleChar(input.now());
    readColonDash();
    readKeyword(input.now());
    readId(input.now());
    readString(input.now());
    readComment(input.now());
    readNone(input.now());
    Token next_token(temp_string, temp_token_type, input.getCurrentLine());
    if (!isspace(temp_string[0])) tokens_list.push_back(next_token);
    input.advanceBy(temp_string.length());
  }
  Token last_token("", ENDFILE, input.getCurrentLine());
  tokens_list.push_back(last_token);
}

void LexicalAnalyzer::readSingleChar(char c)
{
  temp_string = c;
  switch (c){
    case '.': temp_token_type = PERIOD;
              break;
    case ',': temp_token_type = COMMA;
              break;
    case '?': temp_token_type = Q_MARK;
              break;
    case '(': temp_token_type = LEFT_PAREN;
              break;
    case ')': temp_token_type = RIGHT_PAREN;
              break;
    case ':': temp_token_type = COLON;
              break;
    case '*': temp_token_type = MULTIPLY;
              break;
    case '+': temp_token_type = ADD;
              break;                          
    default: temp_string = "";
  }
}

void LexicalAnalyzer::readColonDash()
{
  if (temp_string == ":")
  {
    if (input.lookAhead(1) == '-')
    {
      temp_string = ":-";
      temp_token_type = COLON_DASH;
    }
  }
}

void LexicalAnalyzer::readKeyword(char c)
{
  string keyword = "";
  switch (c){
    case 'S': {
      keyword = "Schemes";
      temp_token_type = SCHEMES;
    }
    break;
    case 'F': {
      keyword = "Facts";
      temp_token_type = FACTS;
    }
    break;
    case 'R': {
      keyword = "Rules";
      temp_token_type = RULES;
    }
    break;
    case 'Q': {
      keyword = "Queries";
      temp_token_type = QUERIES;
    }
    break;
  }
  for (int i = 0; i < keyword.length(); i++) {
    if ((input.lookAhead(i)) == keyword[i]) temp_string += keyword[i];
    else {
      keyword = "";
      temp_string = "";
    }
  }
}

void LexicalAnalyzer::readId(char c)
{
  if (isalpha(c)) {
    string temp_id_string;
    temp_id_string += c;
    int i = 1;
    while (isalnum(input.lookAhead(i))){
      temp_id_string += input.lookAhead(i);
      i++;
    }
    if (temp_id_string.length() > temp_string.length())
    {
      temp_string = temp_id_string;
      temp_token_type = ID;
    }
  }
}

void LexicalAnalyzer::readString(char c){
  if (c == '\'') {
    temp_string = c;
    bool endofstring = false;
    int i = 1;
    while (!endofstring){
      if ((input.lookAhead(i) == '\'') && (input.lookAhead(i+1) != '\'')){
        temp_string += '\'';
        endofstring = true;
        temp_token_type = STRING;
      }
      else if ((input.lookAhead(i) == '\'') && (input.lookAhead(i+1) == '\''))
      {
        temp_string += '\'';
        temp_string += '\'';
        i+= 2;
      }
      else{
        if (input.lookAhead(i) != '\0'){
          temp_string += input.lookAhead(i);
          i++;
        }
        else{
          temp_token_type = UNDEFINED;
          endofstring = true;
        }
      }
    }
  }
}

void LexicalAnalyzer::readComment(char c){
  if (c == '#'){
    temp_string = c;
    int i = 1;
    bool multiline = false;
    bool endofcomment = false;
    if (input.lookAhead(1) == '|') {
      multiline = true;
      temp_string += '|';
      i++;
    }
    if (!multiline) {
      while(!endofcomment){
        if ((input.lookAhead(i) == '\n') || (input.lookAhead(i) == '\0')){
          endofcomment = true;
        }
        else{
          temp_string += input.lookAhead(i);
          i++;
        }
      }
      temp_token_type = COMMENT;
    }
    else {
      while(!endofcomment){
        if ((input.lookAhead(i) == '|')&&(input.lookAhead(i+1) == '#')) {
          endofcomment = true;
          temp_string += "|#";
        }
        else if (input.lookAhead(i) == '\0') {
          endofcomment = true;
          temp_token_type = UNDEFINED;
          return;
        }
        else {
          temp_string += input.lookAhead(i);
          i++;
        }
        temp_token_type = COMMENT;
      }
    }
  }
}

void LexicalAnalyzer::readNone(char c)
{
  if (temp_string == "") {
    temp_string = input.now();
    temp_token_type = UNDEFINED;
  }
}

void LexicalAnalyzer::printV()
{
  for (int i = 0; i<tokens_list.size(); i++)
  {
    cout << tokens_list[i].toString() << endl;
  }
  cout <<"Total Tokens = "<< tokens_list.size();
}